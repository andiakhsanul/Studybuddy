<?php $__env->startSection('content'); ?>
<div class="row pt-4">
    <div class="col">
        <div class="card mb-3">
            <div class="card-header text-center bg-primary">
                <h4 class="text-white">Notifikasi <?php echo e($namaUser); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="table-responsive">
    <table class="table table-striped border border-white">
        <thead>
            <tr>
                <th class="bg-primary text-white border-bottom">Notifikasi</th>
                <th class="bg-primary text-white">Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pengingat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="bg-light text-dark border-bottom">
                    <?php if($item->skala_prioritas == 1): ?>
                        <span class="text-danger">Tugas Penting:</span>
                    <?php else: ?>
                        <span class="text-success">Tugas Sampingan:</span>
                    <?php endif; ?>
                    <?php echo e($item->waktuSisa); ?>

                </td>
                <td class="bg-light text-dark">
                    <strong><?php echo e($item->judulCatatan); ?></strong><br>
                    <?php echo e($item->keterangan); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" class="text-center text-primary"><b>Belum ada notifikasi yang masuk</b></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>



<div class="row pt-4">
    <div class="col">
        <div class="card mb-3">
            <div class="card-header text-center bg-primary">
                <h4 class="text-white">Notifikasi <?php echo e($namaUser); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="table-responsive">
    <table class="table table-striped border border-white">
        <thead>
            <tr>
                <th class="bg-primary text-white border-bottom">Notifikasi</th>
                <th class="bg-primary text-white">Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="bg-light text-dark border-bottom">
                    <span class="text-danger">Tugas Penting: 30 Menit</span> Waktu Sisa
                </td>
                <td class="bg-light text-dark">
                    <strong class="text-primary">Judul Catatan : UTS Semester 3</strong><br>
                    Keterangan : Projek Laravel Workshop
                </td>
            </tr>
            <tr>
                <td class="bg-light text-dark border-bottom">
                    <span class="text-success">Tugas Sampingan: 5 Menit</span> Waktu Sisa
                </td>
                <td class="bg-light text-dark">
                    <strong class="text-primary">Judul Catatan : Event Musik</strong><br>
                    Keterangan : Latihan Nyanyi
                </td>
            </tr>
            <tr>
                <td colspan="2" class="text-center text-primary"><b>Belum ada notifikasi yang masuk</b></td>
            </tr>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.appUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/pages/users/notifikasi.blade.php ENDPATH**/ ?>