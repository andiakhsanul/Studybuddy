<?php $__env->startSection('content'); ?>
    <main>

        <h1>Analytics</h1>
        <!-- Analyses -->
        <div class="analyse">
            <div class="sales">
                <div class="status">
                    <div class="info">
                        <h3></h3>users
                        <h1><?php echo e($userCount); ?></h1>
                    </div>
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36" style="stroke-dasharray: <?php echo e($userCount * 20); ?> 200;">
                            </circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($userCount * 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="visits">
                <div class="status">
                    <div class="info">
                        <h3>Tugas</h3>
                        <h1><?php echo e($tugasCount); ?></h1>
                    </div>
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36"
                                style="stroke-dasharray: <?php echo e($tugasCount * 20); ?> 200;"></circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($tugasCount * 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="searches">
                <div class="status">
                    <div class="info">
                        <h3>Tugas kategori</h3>
                        <h1><?php echo e($kategoriCount); ?></h1>
                    </div>
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36"
                                style="stroke-dasharray: <?php echo e($kategoriCount * 20); ?> 200;"></circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($kategoriCount * 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End of Analyses -->

        <!-- New Users Section -->
        <div class="new-users">
            <h2>New Users</h2>
            <div class="user-list">
                <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="user">
                        <h2><?php echo e($user->NAMA); ?></h2>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/pages/Admin/analyticsadmin.blade.php ENDPATH**/ ?>