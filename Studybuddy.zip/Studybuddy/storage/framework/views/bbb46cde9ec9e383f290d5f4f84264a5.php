<?php $__env->startSection('content'); ?>
    <main>
        <h1>Analytics</h1>
        <!-- Analyses -->
        <div class="analyse">
            <div class="sales">
                <div class="status">
                    <div class="info">
                        <h3 style="text-align: center">Total Akun User</h3>
                        <h1><?php echo e($userCount); ?></h1>
                    </div>
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36" style="stroke-dasharray: <?php echo e($userCount * 20); ?> 200;">
                            </circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($userCount * 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="visits">
                <div class="status">
                    <div class="info">
                        <h3 style="text-align: center">Total Tugas User</h3>
                        <h1><?php echo e($tugasCount); ?></h1>
                    </div>
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36"
                                style="stroke-dasharray: <?php echo e($tugasCount * 20); ?> 200;"></circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($tugasCount * 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="searches">
                <div class="status">
                    <div class="info">
                        <h3 style="text-align: center">Kategori Catatan</h3>
                        <h1><?php echo e($kategoriCount); ?></h1>
                    </div>
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36"
                                style="stroke-dasharray: <?php echo e($kategoriCount * 20); ?> 200;"></circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($kategoriCount * 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="analyse">
            <div class="sales">
                <div class="status">
                    <div class="info">
                        <h3 style="text-align: center">Total Akun Users</h3>
                    </div>
                </div>
                <div class="status" style="margin-top: 30%; margin-left:18%; margin-bottom:10%">
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36"
                                style="stroke-dasharray: <?php echo e($userCount * 20); ?> 200;">
                            </circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($userCount * 2); ?></p>
                        </div>
                    </div>
                </div>
                <h1 style="text-align: center"><?php echo e($userCount); ?></h1>
            </div>
            <div class="visits">
                <div class="status">
                    <div class="info">
                        <h3 style="text-align: center">Total Catatan User</h3>
                    </div>
                </div>
                <div class="status" style="margin-top: 30%; margin-left:18%; margin-bottom:10%">
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36"
                                style="stroke-dasharray: <?php echo e($catatanCount * 20); ?> 200;"></circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($catatanCount * 2); ?></p>
                        </div>
                    </div>
                </div>
                <h1 style="text-align: center"><?php echo e($catatanCount); ?></h1>
            </div>
            <div class="searches">
                <div class="kategori-usage">
                    <h3>Kategori Penggunaan</h3>
                    <ul>
                        <?php $__currentLoopData = $kategoriUsage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                Kategori <?php echo e($usage->nama_kategori); ?>: <?php echo e($usage->total); ?> kali dipakai
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="chart-container">
                    <canvas id="kategoriChart"></canvas>
                </div>
            </div>
        </div>
        <!-- End of Analyses -->

        <!-- New Users Section -->
        <div class="new-users">
            <h2>New Users</h2>
            <div class="user-list">
                <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="user">
                        <h2><?php echo e($user->NAMA); ?></h2>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/pages/Admin/analyticsadmin.blade.php ENDPATH**/ ?>