<?php $__env->startSection('content'); ?>
    <main>
        <div class="analyse">
            <div class="searches">
                <div class="status">
                    <div class="info">
                        <h3>Catatan Tugas User</h3>
                    </div>
                </div>
                <div class="status" style="margin-top: 30%; margin-left:18%; margin-bottom:10%">
                    <div class="progresss">
                        <svg>
                            <circle cx="38" cy="38" r="36"
                                style="stroke-dasharray: <?php echo e($tugasCount * 20); ?> 200;"></circle>
                        </svg>
                        <div class="percentage">
                            <p>+<?php echo e($tugasCount * 2); ?></p>
                        </div>
                    </div>
                </div>
                <h1 style="text-align: center"><?php echo e($tugasCount); ?></h1>
            </div>
            <div class="searches">
                <div class="top-users">
                    <h3 style="color: #1B9C85;">Top Users</h3>
                    <ul>
                        <?php $__currentLoopData = $topUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                User <?php echo e($user->nama_user); ?>: <?php echo e($user->total_tugas); ?> tugas
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="top-phrases">
                    <h3 style="color: #FF0060;">Kalimat Sering Muncul</h3>
                    <ul>
                        <?php $__currentLoopData = $topPhrases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phrase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                Kalimat: <?php echo e($phrase->DESK_TUGAS); ?> - <?php echo e($phrase->total); ?> kali digunakan
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="chart-container">
                    <canvas id="topusersChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="topphrasesChart"></canvas>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/pages/Admin/tugasadmin.blade.php ENDPATH**/ ?>