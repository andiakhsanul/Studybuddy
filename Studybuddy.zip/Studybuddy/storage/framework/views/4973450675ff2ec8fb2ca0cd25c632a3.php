<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('CSS/admin.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">


    <title>Admin</title>
</head>

<body>
    <?php echo $__env->make('partials.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('partials.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<script src="orders.js"></script>
<script src="js/admin.js"></script>

</html>
<?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/Layout/appadmin.blade.php ENDPATH**/ ?>