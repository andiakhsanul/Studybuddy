<?php $__env->startSection('content'); ?>
<main>

    <h1>users</h1>

</main>

<script src="orders.js"></script>
<script src="js/admin.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/pages/Admin/usersadmin.blade.php ENDPATH**/ ?>