<?php $__env->startComponent('mail::message'); ?>

    <?php $__env->startComponent('mail::button', ['url'=> url('verify/'.$validatedData['remember_token'])]); ?>
        verify
    <?php echo $__env->renderComponent(); ?>

    <p>tolong kontak</p>

    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/emails/register.blade.php ENDPATH**/ ?>