<?php $__env->startSection('login'); ?>
    <section class="vh-100">
        <div class="container py-5 h-100">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::has('loginError')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('loginError')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="px-5 ms-xl-4">
                <div class="d-flex align-items-center mb-4">
                    <img src="images/logoTitle/logoweb.png" alt="Logo" width="55" height="55" class="mr-2"
                        style="margin-right: 10px;">
                    <span class="h1 fw-bold mb-0">StudyBuddy</span>
                </div>
            </div>

            <div class="row d-flex align-items-center justify-content-center h-100">
                <div class="col-md-8 col-lg-7 col-xl-6">
                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg"
                        class="img-fluid" alt="Phone image">
                </div>
                <div class="col-md-7 col-lg-5 col-xl-5 offset-xl-1 border rounded shadow">
                    <form action="<?php echo e(route('submitLogin')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <h3 class="fw-bold mb-3 pb-3 text-center pt-4 fs-2">Login Siswa</h3>

                        <!-- Email input -->
                        <div class="form-outline mb-4">
                            <label class="form-label" for="email">Alamat Email</label>
                            <input type="email" id="email" class="form-control" name="EMAIL"
                                value="<?php echo e(old('EMAIL')); ?>" />
                        </div>

                        <!-- Password input -->
                        <div class="form-outline mb-4">
                            <label class="form-label" for="password">Password</label>
                            <input type="password" id="password" class="form-control" name="PASSWORD" />
                        </div>

                        <!-- Submit button -->
                        <button type="submit"
                            class="btn btn-primary btn-block form-control form-control-lg shadow btn-custom"
                            >Login</button>
                        <div class="divider d-flex align-items-center my-4">
                            <p class="text-center fw-bold mx-3 mb-0 text-muted">Atau</p>
                        </div>

                        <div class="flex-container">
                            <p>Belum Memiliki Akun?</p>
                            <p><a href="<?php echo e(route('registerForms')); ?>" class="link-info">Daftar Akun</a></p>
                        </div>
                        <div class="flex items-center justify-center mt-4">

                            <a href="/auth/google"
                                class="mr-2 inline-block items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-400 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                                Register Google
                            </a>
                            <br>
                            <a href="/auth/github"
                                class="px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-500">
                                Register GitHub
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andi akhsanul\Documents\GitHub\Studybuddy\Studybuddy\resources\views/pages/Index/login.blade.php ENDPATH**/ ?>