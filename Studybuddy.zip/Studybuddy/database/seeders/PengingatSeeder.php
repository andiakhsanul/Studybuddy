<?php

namespace Database\Seeders;

// database/seeders/PengingatSeeder.php

use Illuminate\Database\Seeder;
use App\Models\Pengingat;
use App\Models\Mahasiswa;

class PengingatSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

    }
}

